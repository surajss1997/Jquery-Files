module.exports = {
  SRC: './src/',
  DIST: './dist/',
};
