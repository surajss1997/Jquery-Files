# Card Slider Jquery Plugin
サンプル : http://apps.jeromedupuis.net/plugins/card-slider/app/<br />

## Install
npm clone https://github.com/jeromedupuis/card-slider.git <br />
cd card-slider <br />
npm install <br />
npm run start <br />

## Description
Card Slider for 320px width mobile game<br />
